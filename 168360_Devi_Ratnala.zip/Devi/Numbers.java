public class Numbers{
	public static void main(String [] str){
		for(int i=1; i<=10; i++){
			int n=0;
			while(n<=9){
				System.out.print(10*n+i+"\t");
				n++;
			}
			System.out.println();
		}

	}

}

