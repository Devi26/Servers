public class Occurence {
    public static void main(String []str){
        int arr[]={1,1,1,2,2,3};
        int res = 0,n1=0,n2=0,n3=0; 
        int n =arr.length ; 
        for (int i=0; i<n; i++) {
            if (arr[i]==1) 
                n1++; 
            else if(arr[i]==2)
                n2++;
            else if(arr[i]==3)
                n3++;
        }
        System.out.println("occurance of 1 = "+n1+" occurance of 2 = "+n2+" occurance of 3 = "+n3);
    }
}