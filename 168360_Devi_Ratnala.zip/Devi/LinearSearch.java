public class LinearSearch{
	public static void main(String [] str){
		int array[] = {10, 30, 95, 46, 29, 18};
		int size = array.length;
		int value = 18;
		
		for(int i = 0; i<=size-1; i++){
			if(array[i]==value)
				System.out.println(" Required value found index is : " + i);
			else
				System.out.println(" Required element not found " );
		}
	}
}