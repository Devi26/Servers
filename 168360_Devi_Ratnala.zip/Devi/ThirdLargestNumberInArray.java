public class ThirdLargestNumberInArray{
	public static void main(String [] str){
		int temp, size;
		int array[] = {10,20,40,30,50,5};
		size = array.length;
		for(int i = 0; i < size; i++){
			for(int j = i+1; j<size; j++){
				if(array[i]<array[j]){
					temp = array[i];
					array[i] = array[j];
					array[j] = temp;
				}
				
			}
		
		}
		for(int i = 0; i < size; i++){
			
			System.out.println(array[i]);
		}
		System.out.println("The third largest number is : " + array[size-1]);
	}
}