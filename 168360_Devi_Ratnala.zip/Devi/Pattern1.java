public class Pattern1{
    public static void main(String [] str){
     int i,j;
      for(i=1;i<=4;++i){
        for(j=1;j<=i;++j){
                System.out.print(+i);   
     }
        System.out.println();
     }
        
    }
}