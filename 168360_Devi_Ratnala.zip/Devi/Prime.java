public class Prime{
	public static void main(String [] str){
		int array[] = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18};
		int num = 0;
		String primeNumbers = " ";
			for(int i = 0; i<array.length; i++){
				int count=0;
				for(num=i; num>=1; num--){
					if(i%num==0){
						count = count + 1;
					}
				}
				if(count == 2){
					primeNumbers = primeNumbers+ i +" ";
				}
				
			}
			System.out.println(" Prime Numbers are ");
			System.out.println(primeNumbers);
			
	}
}