public class EvenOdd{
	public static void main(String [] str){
		int []even=new int[50];
		int []odd=new int[50];
		int e = 0,o = 0; 
		int n = 100;
		for(int i=2; i<=n; i++){
			if(i%2==0){
				even[e]=i;
				e++;
			}
			else{
				odd[o]=i;
				o++;
			}
		}
		System.out.println("Even Numbers");
		System.out.println(" ");
		for(int j=0; j<e; j++){
			System.out.print(even[j]+ " ");
		}
		System.out.println();
		System.out.println("Odd Numbers");
		System.out.println(" ");
		for(int l=0; l<o; l++){
			System.out.print(odd[l]+ " ");
		}
		
	}	
}