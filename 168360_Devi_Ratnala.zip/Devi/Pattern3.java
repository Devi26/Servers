public class Pattern3{
    public static void main(String [] str){
     int i,j;
      for(i=1;i<=4;++i){
        for(j=1;j<=i;++j){
                System.out.print(+j);   
     }
        System.out.println();
     }
        
    }
}