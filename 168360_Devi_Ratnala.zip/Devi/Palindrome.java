public class Palindrome{
	public static void main(String [] str){
		int n = 12321, m, rev = 0, rem;
		m=n;
		while(n>0){
			rem = n%10;
			rev = rev*10+rem;
			n=n/10;
		}
		if(m==rev){
			System.out.println("given number is a Palindrome");
		}
		else{
			System.out.println("given number is not a Palindrome");
		}
	}
}