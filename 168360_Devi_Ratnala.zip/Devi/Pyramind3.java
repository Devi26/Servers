public class Pyramind3 {
    public static void main(String[] args){
           int j;
           int rows = 8;
           for (int i = 1; i <= rows; i++) {
                  for (j = 1; j <= rows - i; j++)
                        System.out.print(" ");
                  for (int k = j + 1; k <= rows; k++) 
                        System.out.print("*");               
                  for (int k = rows; k > j - 1; k--)
                        System.out.print("*");                
                  System.out.println();
 
           }
    }
 
}