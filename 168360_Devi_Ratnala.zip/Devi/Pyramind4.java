public class Pyramind4 {
    public static void main(String[] args) {
           int rows = 6;
           System.out.println("");
           int nextNumber = 1;
           for (int i = 1; i <= rows; i++) {
                  for (int j = 1; j <= i; j++) {
                        System.out.print(nextNumber<10 ? ("  " + nextNumber++) : (" " + nextNumber++) ); 
                  }
                  System.out.println();
           }
           
 
    }
}
