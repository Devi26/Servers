//package com.cg.search;
public class BinarySearch {
    public static void main(String[] args) {
        int a[]= {1,2,6,5,3};
        int item=4,first=0,middle;
        int len=a.length;
        int last=len-1;
        middle=(first+last)/2;
        while(first<=last) {
            if(a[middle]<item)
                first=middle+1;
            else if(a[middle]==item) {
                System.out.println(item+" found at location "+ (middle+1));
                break;}
            else
                last=middle-1;

            middle=(first+last)/2;
        }
        if(first>last)
            System.out.println(item+" not found");

    }
}