public class Average{  
	public static void main(String args[]){  
		int a = 10,b=20,c=30;
		float d = (a+b+c)/3;
		System.out.println("Average : " + d);
	}
}