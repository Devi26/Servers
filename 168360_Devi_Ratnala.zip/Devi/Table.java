public class Table{
	public static void main(String [] str){
		for(int i=1; i<=10; i++){
			int n=1;
			while(n<=10){
				System.out.print(""+i+"*"+n+"="+n*i+"\t");
				n++;
			}
			System.out.println(); 
		}
	}
}