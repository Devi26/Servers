public class Amstrong{
	public static void main(String [] args){
		int n = 153, num, rem, sum = 0;
		
		num = n;
		while(num!=0){
			rem = num % 10;
			sum = sum + rem*rem*rem;
			num = num/10;
		}
		if(sum == n)	
			System.out.println("given " + n + " is an amstrong");
		else
			System.out.println("given " + n + " is not an amstrong");
	}
}