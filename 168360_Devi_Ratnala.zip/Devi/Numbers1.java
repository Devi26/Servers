public class Numbers1{
	public static void main(String [] str){
		for(int i=1; i<=10; i++){
			for(int n=0; n<=9; n++){
				System.out.print(10*n+i+"\t");
			}
	    System.out.println();
		} 

	}

}
