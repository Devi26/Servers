public class ArrayRearrange{
    public static void main(String[] args){
        int arr[]={1,2,3,4,5,6,7,8,9};
        int rarr[]=new int[9];
        int l=arr.length;//l=9
        int p=l-1,m=0;
        for(int i=0;i<l;i+=2){
            rarr[i]=arr[p];
            p--;
        }
        for(int j=1;j<l-1;j+=2){
            rarr[j]=arr[m];
            m++;
        }
        for(int k=0;k<9;k++){
            System.out.print(rarr[k]+" ");
        }
        }
}
