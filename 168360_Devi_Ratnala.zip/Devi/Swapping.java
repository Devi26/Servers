public class Swapping{
	public static void main(String [] str){
		int a = 26, b = 31;
		System.out.println("Values of a and b before Swapping " + a + " " + b );
		a = a + b;
		b = a - b;
		a = a - b;
		System.out.println("Values of a and b after Swapping " + a + " " + b );
	}
}