public class DeciNumberViceVersa{
    public static void main(String [] args) 
    {
        int n=12,a,c=0,val=0,t;
        String st="",st2="";
        int[] str=new int[20];
        while(n > 0)
        {
            a = n % 2;
            str[c]=a;
            c++;
            n = n / 2;
        }
        t=c;
        while(t>0){
          val+= str[t-1]*(Math.pow(2,t-1));
            t--;
        }
        System.out.println("Decimal Represention"+val);
        System.out.println("Binary Representation");
        for(int j=c-1;j>=0;j--){
        st+=str[j];
        System.out.print(str[j]);
         }
         System.out.println();
            for(int u=c-1;u>=0;u--){
              st2+=st.charAt(u);
         
            }
            System.out.println(st2);
            if(st.equals(st2))
         System.out.print("Found is panlindrome!");
         else
         System.out.print("Found is not Panlindrome!");
         
         
         
         
        
    } 
}
