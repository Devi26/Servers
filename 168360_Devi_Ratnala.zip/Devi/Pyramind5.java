public class Pyramind5 {
    public static void main(String[] args) {
           int n = 6;
           System.out.println(""); 
                 for (int i = n; i >0; i--){
                     for (int j = i,k=1; k <= i; j--,k++) {
                        System.out.print(j);
                     }
                  System.out.println("");
                 }
 
    }
}