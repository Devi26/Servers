public class LcmHcm{
	public static void main(String [] args){
		int n1 = 10, n2 = 20, nume, deno, lcm, hcm, rem;
		if(n1 > n2){
			nume = n1;
			deno = n2;
		}
		else{
			nume = n2;
			deno = n1;
		}
		rem = nume % deno;
		while(rem!=0){
			nume = deno;
			deno = rem;
			rem = nume % deno;
		}
		hcm = deno;
		lcm = (n1*n2)/hcm;
		System.out.println(hcm + " is the hcm of the given numbers");
		System.out.println(lcm + " is the lcm of the given numbers");
	}
}