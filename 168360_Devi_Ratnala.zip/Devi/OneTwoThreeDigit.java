public class OneTwoThreeDigit {
public static void main(String[] args) {
int arr[]= {2,34,987,256,9,11,4,334,875,34};
int count=0,oneDigit=0,twoDigit=0,threeDigit=0;
for(int i=0;i<arr.length;i++)
{
    while(arr[i]>0)
    {
        arr[i]/=10;
        count++;
    }
    if(count==1)
    {
        oneDigit++;
    }else if(count==2) {
        twoDigit++;
    }
    else {
        threeDigit++;
    }
    count=0;
}
System.out.println("count of one digit : "+oneDigit);
System.out.println("count of two digit : "+twoDigit);
System.out.println("count of three digit : "+threeDigit);
    }

}